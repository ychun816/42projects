
char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i])
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}
#include <stdio.h>

int	main(void)
{
	char m[7] = "hello!";
	char n[] = "you";
	ft_strcpy(m, n);
	printf("%s\n", m);
	char m[7] = "hello world!";
	char n[] = "you are my friend";
	ft_strcpy(m, n);
	printf("%s\n", m);
}