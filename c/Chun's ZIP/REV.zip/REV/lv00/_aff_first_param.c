/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   _aff_first_param.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ylin <ylin@student.42.fr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/07/09 15:28:14 by ylin              #+#    #+#             */
/*   Updated: 2023/07/20 17:52:46 by ylin             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	main(int ac, char **av)
{
	int	i;

	i = 0;
	if (ac == 1)
	{
		write(1, "\n", 1);
		return (0);
	}
	while (av[1][i])
	{
		write(1, &av[1][i], 1);
		i++;
	}
	write(1, "\n", 1);
}

// int	main(int argc, char **argv)
// {
// 	int	j;

// 	j = argc -1;
// 	while (j > 0)
// 	{
// 		ft_putstr(argv[j]);
// 		write(1, "\n", 1);
// 		j--;
// 	}
// }