/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ylin <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/29 14:07:16 by ylin              #+#    #+#             */
/*   Updated: 2023/06/29 17:26:11 by ylin             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>

void	print_nr(int i, int j)
{
	char	c1;
	char	c2;
	char	c3;
	char	c4;

	c1 = '0' + (i / 10);
	c2 = '0' + (i % 10);
	c3 = '0' + (j / 10);
	c4 = '0' + (j % 10);
	write(1, &c1, 1);
	write(1, &c2, 1);
	write(1, " ", 1);
	write(1, &c3, 1);
	write(1, &c4, 1);
}

void	ft_print_comb2(void)
{
	int	a;
	int	b;

	a = 0;
	while (a <= 98)
	{
		b = a + 1;
		while (b <= 99)
		{
			print_nr(a, b);
			if (a == 98 && b == 99)
			{
				break ;
			}
			write(1, ", ", 2);
			b ++;
		}
		a ++;
	}
}
